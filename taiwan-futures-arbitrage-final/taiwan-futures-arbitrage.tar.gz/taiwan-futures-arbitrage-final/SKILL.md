---
name: taiwan-futures-arbitrage
description: 台股期貨自動套利系統 - 期現價差、跨月價差、三角套利
user-invocable: true
requires:
  bins:
    - python3
  packages:
    - shioaji
    - pandas
    - numpy
    - TA-Lib
    - sqlalchemy
---

# Taiwan Futures Arbitrage Skill

自動化台股期貨套利交易系統，支援多種套利策略。

## 功能特性

✅ **期現價差套利**：監控台指期貨與現貨指數價差，自動執行套利
✅ **跨月價差套利**：近月與次月合約價差交易
✅ **三角套利**：台指期 vs 電子期 vs 金融期組合套利
✅ **風險管理**：自動止損、倉位控制、保證金監控
✅ **即時監控**：WebSocket 實時行情，毫秒級響應
✅ **交易日誌**：完整記錄所有交易，支援績效分析

## 可用指令

### 1. 初始化系統

```bash
cd ~/.openclaw/workspace/skills/taiwan-futures-arbitrage
python3 scripts/setup.py --api-key YOUR_KEY --secret-key YOUR_SECRET
```

初次使用需設定永豐 API 憑證和交易參數。

### 2. 掃描套利機會

```bash
python3 scripts/scanner.py --strategy basis --threshold 150
```

**參數說明**：
- `--strategy`: 套利策略 (basis/calendar/triangle)
- `--threshold`: 價差門檻（點數）
- `--format`: 輸出格式 (telegram/text/json)

**範例輸出**：
```
🎯 發現套利機會！
策略: 期現價差套利
台指期 (TXFF4): 21,850
現貨指數: 21,680
價差: +170 點
預期獲利: NT$4,250 / 口
風險評分: 低 (85/100)
建議倉位: 3 口
```

### 3. 執行套利交易

```bash
python3 scripts/trader.py --opportunity-id OPP_20260213_001 --quantity 3
```

**參數說明**：
- `--opportunity-id`: 套利機會 ID（由 scanner 產生）
- `--quantity`: 交易口數
- `--dry-run`: 模擬模式（不實際下單）

### 4. 監控運行中的交易

```bash
python3 scripts/monitor.py --mode realtime
```

顯示當前所有持倉、未平倉盈虧、保證金使用率。

### 5. 查看績效報告

```bash
python3 scripts/report.py --period 30d --export pdf
```

生成過去 30 天的交易報告，包含：
- 總收益 / 虧損
- 夏普比率
- 最大回撤
- 勝率統計

### 6. 啟動自動交易

```bash
python3 scripts/autotrader.py --strategies basis,calendar --max-positions 10
```

**24/7 自動運行**，自動掃描、執行、監控套利交易。

**安全機制**：
- 每日最大虧損上限
- 單筆交易規模限制
- 異常價格過濾
- 保證金不足自動停止

## Telegram 整合指令

透過 OpenClaw 的 Telegram 介面，可使用自然語言控制：

```
"掃描台指期套利機會，價差門檻 150 點"
→ 執行 scanner.py --strategy basis --threshold 150

"查看目前持倉和盈虧"
→ 執行 monitor.py --mode realtime

"暫停所有自動交易"
→ 執行 autotrader.py --action pause

"產生本週交易報告"
→ 執行 report.py --period 7d
```

## 系統架構

```
taiwan-futures-arbitrage/
├── SKILL.md                    # 本檔案
├── README.md                   # 詳細文件
├── requirements.txt            # Python 套件
├── config/
│   ├── settings.json          # 系統設定
│   └── strategies.json        # 策略參數
├── scripts/
│   ├── setup.py               # 初始化設定
│   ├── scanner.py             # 套利掃描器
│   ├── trader.py              # 交易執行器
│   ├── monitor.py             # 監控系統
│   ├── report.py              # 績效報告
│   └── autotrader.py          # 自動交易引擎
├── lib/
│   ├── shioaji_client.py      # Shioaji API 封裝
│   ├── spread_calculator.py   # 價差計算引擎
│   ├── risk_manager.py        # 風險管理模組
│   ├── order_executor.py      # 訂單執行器
│   └── database.py            # 資料庫介面
└── data/
    ├── trades.db              # 交易紀錄資料庫
    └── logs/                  # 日誌檔案
```

## 風險聲明

⚠️ **本系統僅供教育和實驗用途**

- 期貨交易涉及重大財務風險
- 過去績效不代表未來表現
- 請勿投入您無法承受損失的資金
- 建議先使用永豐模擬帳戶測試
- 實盤交易前請諮詢專業顧問

## 技術支援

- GitHub: [taiwan-futures-arbitrage](https://github.com/your-repo)
- 文件: [完整使用手冊](https://docs.example.com)
- 社群: Telegram 群組討論

---

**授權**: MIT License  
**作者**: Your Name  
**版本**: 1.0.0  
**最後更新**: 2026-02-13
